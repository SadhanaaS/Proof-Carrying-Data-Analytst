const $=id=>document.getElementById(id);
let chartInstances=[];

async function api(url,opts={}){
  const r=await fetch(url,opts);
  const j=await r.json();
  if(!r.ok) throw new Error(j.detail||'Request failed');
  return j;
}

async function health(){
  try{
    const j=await api('/api/health');
    $('health').textContent='Backend online v'+j.version;
  }catch(e){
    $('health').textContent='Backend offline';
    $('health').className='pill danger';
  }
}

async function loadVisualizations(){
  const status=$('chartStatus'), container=$('charts');
  status.textContent='Building charts from the uploaded data...';
  chartInstances.forEach(c=>c.destroy());
  chartInstances=[];
  container.innerHTML='';
  try{
    const j=await api('/api/visualizations');
    if(!j.charts?.length){
      status.textContent='No suitable numeric/categorical/time fields were found for charts.';
      return;
    }
    status.textContent=`${j.charts.length} data-driven visualization${j.charts.length===1?'':'s'} generated.`;
    j.charts.forEach((cfg,i)=>{
      const card=document.createElement('div');
      card.className='chart-card';
      card.innerHTML=`<div class="chart-head"><div><h3>${esc(cfg.title)}</h3><p>${esc(cfg.description||'')}</p></div><span class="chart-type">${esc(cfg.type)}</span></div><div class="canvas-wrap"><canvas id="chart-${i}"></canvas></div>`;
      container.appendChild(card);
      const ctx=$(`chart-${i}`).getContext('2d');
      const chartType=cfg.type==='line'?'line':'bar';
      const options={
        responsive:true,
        maintainAspectRatio:false,
        plugins:{legend:{display:cfg.type==='line'}},
        scales:{
          x:{ticks:{autoSkip:false,maxRotation:45,minRotation:0}},
          y:{beginAtZero:true}
        }
      };
      if(cfg.horizontal){
        options.indexAxis='y';
      }
      chartInstances.push(new Chart(ctx,{
        type:chartType,
        data:{labels:cfg.labels,datasets:[{
          label:cfg.label,
          data:cfg.data,
          borderWidth:2,
          tension:0.25,
          borderRadius:chartType==='bar'?7:0,
          fill:false
        }]},
        options
      }));
    });
  }catch(e){
    status.textContent='Could not generate visualizations: '+e.message;
  }
}

$('uploadBtn').onclick=async()=>{
  const files=$('files').files;
  if(!files.length)return alert('Choose one or more files.');
  const fd=new FormData();
  for(const f of files)fd.append('files',f);
  try{
    const j=await api('/api/upload',{method:'POST',body:fd});
    $('filesList').innerHTML=j.uploaded.map(x=>`<div class="file">✓ ${esc(x)}</div>`).join('');
    await loadVisualizations();
  }catch(e){alert(e.message)}
};

$('resetBtn').onclick=async()=>{
  await api('/api/reset',{method:'POST'});
  $('filesList').innerHTML='';
  $('result').classList.add('hidden');
  chartInstances.forEach(c=>c.destroy());
  chartInstances=[];
  $('charts').innerHTML='';
  $('chartStatus').textContent='Upload a dataset to generate visualizations.';
};

$('analyzeBtn').onclick=async()=>{
  const q=$('question').value.trim();
  if(!q)return alert('Enter a question.');
  $('loading').classList.remove('hidden');
  $('result').classList.add('hidden');
  try{
    const j=await api('/api/analyze',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({question:q})
    });
    render(j);
    await loadVisualizations();
  }catch(e){alert(e.message)}
  finally{$('loading').classList.add('hidden')}
};

function render(j){
  const cls=j.status==='VERIFIED'?'status':(j.status==='UNANSWERABLE'||j.status==='CLARIFICATION'?'status danger':'status warning');
  let html=`<div class="result-card"><span class="${cls}">${esc(j.status)}</span><div class="answer">${esc(j.display_answer||'No reliable answer')}</div><p>${esc(j.explanation||'')}</p><div class="grid"><div class="metric"><b>Confidence</b><br>${esc(j.confidence)}</div><div class="metric"><b>Tables used</b><br>${(j.tables_used||[]).map(esc).join(', ')||'None'}</div><div class="metric"><b>Verification</b><br>${j.execution?.verified?'✓ Reproduced':'—'}</div></div>`;
  if(j.issues?.length){html+=`<div class="section"><h3>Data quality</h3>${j.issues.map(i=>`<div class="issue ${i.severity==='critical'?'critical':''}"><b>${esc(i.code)}</b> — ${esc(i.message)}</div>`).join('')}</div>`}
  if(j.code){html+=`<div class="section"><h3>Generated executable code</h3><pre class="code">${esc(j.code)}</pre></div>`}
  if(j.execution?.first){html+=`<div class="section"><h3>Proof of execution</h3><div class="grid"><div class="metric">Run 1<br><b>${esc(String(j.execution.first.result))}</b></div><div class="metric">Run 2<br><b>${esc(String(j.execution.second.result))}</b></div><div class="metric">Reproducible<br><b>${j.execution.verified?'YES':'NO'}</b></div></div></div>`}
  if(j.evidence?.tables?.length){html+=`<div class="section"><h3>Evidence</h3><table><tr><th>Table</th><th>Rows</th><th>Columns</th></tr>${j.evidence.tables.map(t=>`<tr><td>${esc(t.name)}</td><td>${t.rows}</td><td>${esc(t.columns.join(', '))}</td></tr>`).join('')}</table></div>`}
  html+='</div>';
  $('result').innerHTML=html;
  $('result').classList.remove('hidden');
}

function esc(s){
  return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}

health();
