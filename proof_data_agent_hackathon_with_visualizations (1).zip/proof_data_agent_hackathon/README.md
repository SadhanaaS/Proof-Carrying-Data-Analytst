# Proof-Carrying Data Analyst — HackNex PSI08

A hackathon-grade MVP for **HNX26PSI08: Proof-Carrying Data Analyst (Agentic GenAI)**.

## Core idea
The system does not only return a number. It attempts to provide:

1. Dataset profiling
2. Data-quality checks
3. Question answerability / ambiguity checks
4. Multi-table planning
5. Generated executable Python
6. Code validation
7. Process-isolated execution
8. Two-run reproducibility verification
9. Evidence and proof summary
10. Explicit refusal when the data cannot support an answer

## Stack
- FastAPI
- Pandas / NumPy
- OpenPyXL / XLRD
- pypdf
- Optional OpenAI Responses API
- Vanilla HTML/CSS/JS frontend

## Run on Windows

```powershell
cd proof_data_agent_hackathon
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn backend.main:app --reload
```

Open `http://127.0.0.1:8000`.

## Demo
Upload the three files from `data/`, then ask:

> What was the total amount from Coimbatore customers in 2025?

The deterministic planner can demonstrate joins, date filtering, aggregation, code execution and reproducibility.

Try an intentionally unanswerable question:

> Which customer was the tallest?

The system should refuse because no height field exists.

## Optional LLM mode
Create `.env`/set environment variables:

```text
OPENAI_API_KEY=your_key
OPENAI_MODEL=gpt-5.6-mini
```

The LLM planner is optional. The application has a deterministic fallback so the demo can run without an API key.

## Important security note
The executor uses a restricted Python builtins dictionary and a separate process with a timeout. This is **prototype isolation, not a production-grade security sandbox**. For deployment, execute untrusted generated code inside a hardened container/VM with CPU, memory, filesystem and network restrictions.

## Hackathon extensions
- DuckDB/SQL query planning for larger datasets
- stronger document/table extraction
- row-level evidence for every filtered record
- semantic schema matching
- currency conversion with explicit source/rate provenance
- robust date ambiguity resolution
- adversarial evaluation suite
- Docker/VM sandbox
- authentication and per-session storage


## Visualization update
The frontend now includes a dynamic chart dashboard. After upload, `/api/visualizations` analyzes the loaded tables and returns chart specifications for dataset size, missing values, time trends, and useful category-vs-numeric comparisons. The frontend renders these charts with Chart.js. Charts are based on the actual uploaded data and refresh after upload, analysis, and reset.
