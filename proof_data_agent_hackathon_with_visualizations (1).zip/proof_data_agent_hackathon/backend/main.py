from __future__ import annotations
import os, uuid
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from .config import APP_NAME, UPLOAD_DIR, MAX_UPLOAD_MB
from .data_manager import DataManager
from .agent import AnalystAgent
from .models import QuestionRequest

app=FastAPI(title=APP_NAME, version="2.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
dm=DataManager(); agent=AnalystAgent(dm)

@app.get("/api/health")
def health(): return {"ok":True,"service":APP_NAME,"version":"2.0.0"}

@app.get("/api/datasets")
def datasets(): return {"summary":dm.summary()}

@app.post("/api/upload")
async def upload(files: list[UploadFile]=File(...)):
    results=[]
    for f in files:
        ext=Path(f.filename or "").suffix.lower()
        if not ext: continue
        data=await f.read()
        if len(data)>MAX_UPLOAD_MB*1024*1024: raise HTTPException(413,f"{f.filename} exceeds {MAX_UPLOAD_MB} MB")
        path=UPLOAD_DIR / f"{uuid.uuid4().hex}_{Path(f.filename).name}"
        path.write_bytes(data)
        try:
            name,_=dm.load_file(str(path)); results.append(name)
        except Exception as e: raise HTTPException(400,f"Could not load {f.filename}: {e}")
    return {"uploaded":results,"summary":dm.summary()}

@app.post("/api/reset")
def reset():
    dm.clear(); return {"ok":True}

@app.post("/api/analyze")
def analyze(req: QuestionRequest):
    if not dm.tables and not dm.documents: raise HTTPException(400,"Upload at least one dataset/document first.")
    return agent.analyze(req.question)


@app.get("/api/visualizations")
def visualizations():
    """Return safe, data-driven chart specifications for the current datasets."""
    import pandas as pd

    charts = []
    # Dataset-size comparison
    if dm.tables:
        rows_data = [{"name": str(name), "rows": int(len(df))} for name, df in dm.tables.items()]
        charts.append({
            "type": "bar",
            "title": "Rows by dataset",
            "description": "Number of records currently loaded from each table.",
            "labels": [x["name"] for x in rows_data],
            "data": [x["rows"] for x in rows_data],
            "label": "Rows"
        })

    # Build a small number of useful charts from each table.
    for name, df in dm.tables.items():
        if df.empty:
            continue

        # Missing values by column
        missing = df.isna().sum()
        missing = missing[missing > 0].sort_values(ascending=False)
        if len(missing):
            charts.append({
                "type": "bar",
                "title": f"Missing values — {name}",
                "description": "Columns with missing values detected by the profiler.",
                "labels": [str(x) for x in missing.index],
                "data": [int(x) for x in missing.values],
                "label": "Missing values",
                "horizontal": True
            })

        # Time trend: detect date-like columns and a numeric measure.
        date_col = None
        date_series = None
        for col in df.columns:
            parsed = pd.to_datetime(df[col], errors="coerce", dayfirst=True)
            if parsed.notna().sum() >= max(2, int(len(df) * 0.5)):
                date_col, date_series = col, parsed
                break

        numeric_cols = list(df.select_dtypes(include="number").columns)
        if date_col and numeric_cols:
            measure = next((c for c in numeric_cols if any(k in str(c).lower() for k in
                ["amount", "revenue", "sales", "price", "total", "value", "quantity", "qty"])), numeric_cols[0])
            temp = pd.DataFrame({"date": date_series, "value": pd.to_numeric(df[measure], errors="coerce")}).dropna()
            if len(temp) >= 2:
                temp["period"] = temp["date"].dt.to_period("M").astype(str)
                grouped = temp.groupby("period", as_index=False)["value"].sum()
                charts.append({
                    "type": "line",
                    "title": f"{measure} over time — {name}",
                    "description": f"Monthly sum of {measure} based on the uploaded data.",
                    "labels": grouped["period"].tolist(),
                    "data": [float(x) for x in grouped["value"].tolist()],
                    "label": str(measure)
                })

        # Category vs numeric: choose a low-cardinality text column and a useful numeric measure.
        categorical = [c for c in df.columns if (df[c].dtype == "object" or str(df[c].dtype).startswith("string"))
                       and 2 <= df[c].nunique(dropna=True) <= 12]
        if numeric_cols and categorical:
            measure = next((c for c in numeric_cols if any(k in str(c).lower() for k in
                ["amount", "revenue", "sales", "price", "total", "value", "quantity", "qty"])), numeric_cols[0])
            cat = next((c for c in categorical if any(k in str(c).lower() for k in
                ["customer", "product", "category", "city", "name", "type"])), categorical[0])
            temp = df[[cat, measure]].copy()
            temp[measure] = pd.to_numeric(temp[measure], errors="coerce")
            temp = temp.dropna()
            grouped = temp.groupby(cat, as_index=False)[measure].sum().sort_values(measure, ascending=False).head(10)
            if len(grouped) >= 2:
                charts.append({
                    "type": "bar",
                    "title": f"{measure} by {cat} — {name}",
                    "description": f"Top categories by summed {measure}.",
                    "labels": [str(x) for x in grouped[cat]],
                    "data": [float(x) for x in grouped[measure]],
                    "label": str(measure),
                    "horizontal": len(grouped) >= 6
                })

    return {"charts": charts[:10]}

@app.get("/api/profiles")
def profiles():
    from .profiler import profile_all
    return profile_all(dm.tables)

frontend=Path(__file__).resolve().parent.parent/"frontend"
app.mount("/static",StaticFiles(directory=str(frontend)),name="static")
@app.get("/")
def home(): return FileResponse(str(frontend/"index.html"))
