from __future__ import annotations
import json
from typing import Any
from .config import OPENAI_API_KEY, OPENAI_MODEL

class LLMClient:
    def __init__(self):
        self.enabled=bool(OPENAI_API_KEY)
        self.client=None
        if self.enabled:
            try:
                from openai import OpenAI
                self.client=OpenAI(api_key=OPENAI_API_KEY)
            except Exception:
                self.enabled=False

    def make_plan(self, question, profiles, context):
        if not self.enabled: raise RuntimeError("LLM not configured")
        system="""You are the planning engine for a proof-carrying data analyst. Return ONLY valid JSON with keys: code, tables_used, operation, explanation. The code must be executable Python using only pandas and variables named tables (dict[str, DataFrame]). It must assign the final scalar/table to result and print(result). Never use os, subprocess, socket, requests, eval, exec, open, pathlib, or network access. Prefer explicit joins, filters and aggregations. Do not invent columns. If the question cannot be answered from the supplied schema, raise ValueError with a clear reason."""
        payload={"question":question,"profiles":profiles,"sample_context":context}
        response=self.client.responses.create(model=OPENAI_MODEL, input=[{"role":"system","content":system},{"role":"user","content":json.dumps(payload,default=str)}])
        text=response.output_text
        return json.loads(text)
