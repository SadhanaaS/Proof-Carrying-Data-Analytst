from __future__ import annotations
import json
import re
from pathlib import Path
from typing import Dict, Tuple
import pandas as pd

SUPPORTED = {".csv", ".xlsx", ".xls", ".json", ".txt", ".pdf"}

class DataManager:
    def __init__(self):
        self.tables: Dict[str, pd.DataFrame] = {}
        self.documents: Dict[str, str] = {}
        self.source_paths: Dict[str, str] = {}

    def clear(self):
        self.tables.clear(); self.documents.clear(); self.source_paths.clear()

    def load_file(self, path: str) -> Tuple[str, str]:
        p = Path(path); ext = p.suffix.lower()
        if ext not in SUPPORTED:
            raise ValueError(f"Unsupported file type: {ext}")
        if ext == ".csv":
            df = pd.read_csv(p)
            name = p.name
            self.tables[name] = df
        elif ext in {".xlsx", ".xls"}:
            book = pd.ExcelFile(p)
            if len(book.sheet_names) == 1:
                name = p.name
                self.tables[name] = pd.read_excel(p)
            else:
                name = p.name
                for sheet in book.sheet_names:
                    self.tables[f"{p.name}::{sheet}"] = pd.read_excel(p, sheet_name=sheet)
        elif ext == ".json":
            with open(p, encoding="utf-8") as f: data = json.load(f)
            if isinstance(data, list): df = pd.DataFrame(data)
            elif isinstance(data, dict):
                try: df = pd.json_normalize(data)
                except Exception: df = pd.DataFrame([data])
            else: raise ValueError("JSON must contain an object or array")
            name = p.name; self.tables[name] = df
        elif ext == ".txt":
            text = p.read_text(encoding="utf-8", errors="ignore")
            self.documents[p.name] = text
            name = p.name
        elif ext == ".pdf":
            text = self._read_pdf(p)
            self.documents[p.name] = text
            name = p.name
        self.source_paths[name] = str(p)
        return name, ext

    def _read_pdf(self, path: Path) -> str:
        try:
            from pypdf import PdfReader
            reader = PdfReader(str(path))
            return "\n".join((page.extract_text() or "") for page in reader.pages)
        except Exception as e:
            return f"[PDF extraction unavailable: {e}]"

    def summary(self):
        return {
            "tables": {name: {"rows": len(df), "columns": list(map(str, df.columns))} for name, df in self.tables.items()},
            "documents": {name: len(text) for name, text in self.documents.items()}
        }

    def sample_context(self, max_rows=20):
        ctx = []
        for name, df in self.tables.items():
            sample = df.head(max_rows).copy()
            ctx.append({"name": name, "columns": list(map(str, df.columns)), "dtypes": {str(k): str(v) for k,v in df.dtypes.items()}, "sample": sample.where(pd.notna(sample), None).to_dict(orient="records")})
        for name, text in self.documents.items():
            ctx.append({"name": name, "document_excerpt": text[:6000]})
        return ctx
