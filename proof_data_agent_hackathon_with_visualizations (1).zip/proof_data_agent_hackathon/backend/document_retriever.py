from __future__ import annotations
import re
from typing import Dict, List, Any

class DocumentRetriever:
    """Small local lexical retriever for uploaded TXT/PDF text.
    It returns relevant snippets and never pretends a snippet is a verified numeric calculation.
    """
    def __init__(self, documents: Dict[str,str]):
        self.documents=documents

    def search(self, query: str, top_k: int=5) -> List[Dict[str,Any]]:
        terms={t.lower() for t in re.findall(r"[a-zA-Z0-9]+",query) if len(t)>2}
        hits=[]
        for name,text in self.documents.items():
            chunks=re.split(r"\n\s*\n|(?<=[.!?])\s+",text)
            for idx,ch in enumerate(chunks):
                low=ch.lower(); score=sum(1 for t in terms if t in low)
                if score:
                    hits.append({"document":name,"chunk_index":idx,"score":score,"snippet":ch.strip()[:1000]})
        return sorted(hits,key=lambda x:(-x["score"],x["document"],x["chunk_index"]))[:top_k]
