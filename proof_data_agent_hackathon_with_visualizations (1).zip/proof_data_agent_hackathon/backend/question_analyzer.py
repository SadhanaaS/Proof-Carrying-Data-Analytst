from __future__ import annotations
import re
from typing import Dict, List, Any
import pandas as pd

STOP=set("what was is the a an of in on for by from to and or total how many average avg mean maximum max minimum min highest lowest which who did during between show give calculate tell me".split())

def analyze_question(question: str, tables: Dict[str,pd.DataFrame], issues: List[Dict[str,Any]]) -> Dict[str,Any]:
    q=question.lower().strip()
    columns=[]
    for name,df in tables.items():
        columns.extend([(name,str(c)) for c in df.columns])
    matched=[]
    for name,c in columns:
        if re.search(r"\b"+re.escape(c.lower())+r"\b",q): matched.append((name,c))
    numeric_names={c.lower() for _,c in columns if any(x in c.lower() for x in ["amount","revenue","price","salary","quantity","sales","profit","cost","value","total"])}
    metric_terms=[x for x in ["revenue","sales","profit","amount","salary","price","quantity","orders","count","average","mean","maximum","minimum","total"] if x in q]
    ambiguous=[]
    if "sales" in q:
        possible=[]
        for _,c in columns:
            cl=c.lower()
            if any(k in cl for k in ["revenue","amount","sales","quantity","profit"]): possible.append(c)
        if len(possible)>1 and not any(c.lower() in q for c in possible): ambiguous.append("The term 'sales' could refer to multiple available measures: "+", ".join(sorted(set(possible))))
    year=re.findall(r"\b(20\d{2})\b",q)
    needs_data=not bool(re.search(r"\b(columns?|fields?|schema|rows?|records?)\b",q))
    tokens=[t for t in re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*",q) if t.lower() not in STOP]
    # Heuristic: if question contains a concept not represented by columns, flag only for strong attribute requests.
    if any(w in q for w in ["tallest","height","age","gender","address","fraud","committed fraud"]):
        target=next((w for w in ["height","tallest","age","gender","address","fraud"] if w in q),None)
        found=any(target in c.lower() for _,c in columns) if target else True
        if not found and target:
            return {"answerable":False,"reason":f"The question requires '{target}' information, but no matching field exists in the uploaded data.","matched_columns":matched,"ambiguous":ambiguous,"year":year}
    if ambiguous:
        return {"answerable":False,"reason":ambiguous[0],"clarification":ambiguous[0],"matched_columns":matched,"ambiguous":ambiguous,"year":year}
    if not tables and needs_data:
        return {"answerable":False,"reason":"No tabular data has been uploaded.","matched_columns":[],"ambiguous":[],"year":year}
    return {"answerable":True,"reason":"Sufficient table context appears available for planning.","matched_columns":matched,"ambiguous":ambiguous,"year":year,"metric_terms":metric_terms,"tokens":tokens}
