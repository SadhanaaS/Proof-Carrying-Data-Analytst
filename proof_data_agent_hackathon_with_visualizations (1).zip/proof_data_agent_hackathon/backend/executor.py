from __future__ import annotations
import io
import contextlib
import time
import multiprocessing as mp
from typing import Dict, Any
import pandas as pd
from .code_validator import validate_code

def _worker(code, tables, queue):
    try:
        allowed={"pd":pd,"tables":tables}
        def safe_import(name, globals=None, locals=None, fromlist=(), level=0):
            root=name.split('.')[0]
            if root == "pandas":
                return pd
            if root == "numpy":
                import numpy as np
                return np
            if root == "math":
                import math
                return math
            if root == "datetime":
                import datetime
                return datetime
            raise ImportError(f"Import blocked: {name}")
        safe_builtins={"__import__":safe_import,"print":print,"len":len,"int":int,"float":float,"str":str,"round":round,"min":min,"max":max,"sum":sum,"range":range,"abs":abs,"bool":bool,"enumerate":enumerate,"zip":zip,"sorted":sorted}
        buf=io.StringIO()
        with contextlib.redirect_stdout(buf):
            exec(compile(code,"<generated>","exec"), {"__builtins__":safe_builtins}, allowed)
        result=allowed.get("result")
        queue.put({"ok":True,"result":result,"stdout":buf.getvalue()})
    except Exception as e:
        queue.put({"ok":False,"error":f"{type(e).__name__}: {e}","stdout":""})

def execute(code: str, tables: Dict[str,pd.DataFrame], timeout=8) -> Dict[str,Any]:
    valid,errors=validate_code(code)
    if not valid: return {"ok":False,"error":"Code rejected: "+"; ".join(errors),"stdout":"","duration_ms":0}
    # Do not claim this is a hardened sandbox; this is a prototype process isolation boundary.
    q=mp.Queue(); start=time.perf_counter(); p=mp.Process(target=_worker,args=(code,tables,q),daemon=True); p.start(); p.join(timeout)
    if p.is_alive(): p.terminate(); p.join(); return {"ok":False,"error":"Execution timed out","stdout":"","duration_ms":round((time.perf_counter()-start)*1000,2)}
    duration=round((time.perf_counter()-start)*1000,2)
    result=q.get() if not q.empty() else {"ok":False,"error":"No execution result","stdout":""}
    result["duration_ms"]=duration
    return result
