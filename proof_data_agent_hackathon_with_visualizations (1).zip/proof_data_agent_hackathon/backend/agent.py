from __future__ import annotations
from .data_manager import DataManager
from .profiler import profile_all
from .quality import quality_scan, critical_issue
from .question_analyzer import analyze_question
from .planner import Planner
from .llm_client import LLMClient
from .verifier import verify
from .proof_engine import build_proof
from .evidence import build_evidence
from .document_retriever import DocumentRetriever
from .config import MAX_EXEC_SECONDS

class AnalystAgent:
    def __init__(self, data_manager: DataManager):
        self.dm=data_manager
        self.planner=Planner(LLMClient())

    def analyze(self, question: str):
        profiles=profile_all(self.dm.tables)
        issues=quality_scan(self.dm.tables)
        doc_hits=DocumentRetriever(self.dm.documents).search(question) if self.dm.documents else []
        q=analyze_question(question,self.dm.tables,issues)
        if not q["answerable"]:
            return {"status":"CLARIFICATION" if q.get("clarification") else "UNANSWERABLE","answer":None,"display_answer":"Cannot determine reliably","explanation":q["reason"],"confidence":"NONE","issues":issues,"tables_used":[],"proof":{"status":"NOT ANSWERABLE","reason":q["reason"]},"code":"","execution":{},"evidence":{},"clarification":q.get("clarification")}
        crit=critical_issue(issues)
        if crit:
            # Critical issues do not always make every question impossible, but prevent silent answers.
            return {"status":"DATA_WARNING","answer":None,"display_answer":"Cannot safely determine","explanation":crit["message"],"confidence":"LOW","issues":issues,"tables_used":[],"proof":{"status":"BLOCKED BY DATA QUALITY","reason":crit["message"]},"code":"","execution":{},"evidence":{}}
        try:
            plan=self.planner.plan(question,self.dm.tables,profiles,self.dm.sample_context())
        except Exception as e:
            return {"status":"UNANSWERABLE","answer":None,"display_answer":"Cannot determine reliably","explanation":str(e),"confidence":"NONE","issues":issues,"tables_used":[],"proof":{"status":"PLANNING FAILED","reason":str(e)},"code":"","execution":{},"evidence":{}}
        verification=verify(plan["code"],self.dm.tables,MAX_EXEC_SECONDS)
        if not verification["verified"]:
            return {"status":"FAILED","answer":None,"display_answer":"Verification failed","explanation":verification["reason"],"confidence":"LOW","issues":issues,"tables_used":plan.get("tables_used",[]),"proof":{"status":"FAILED","reason":verification["reason"]},"code":plan["code"],"execution":verification,"evidence":{}}
        result=verification["first"].get("result")
        evidence=build_evidence(self.dm.tables,plan,result)
        evidence["documents"]=doc_hits
        proof=build_proof(question,plan,verification,issues,profiles,evidence)
        return {"status":"VERIFIED","answer":result,"display_answer":self._display(result),"explanation":plan.get("explanation","The result was calculated by executable generated code and reproduced on a second run."),"confidence":proof["confidence"],"issues":issues,"tables_used":plan.get("tables_used",[]),"proof":proof,"code":plan["code"],"execution":verification,"evidence":evidence}

    @staticmethod
    def _display(value):
        if isinstance(value,float):
            if value.is_integer(): return f"{int(value):,}"
            return f"{value:,.4f}".rstrip("0").rstrip(".")
        if isinstance(value,int): return f"{value:,}"
        return str(value)
