from __future__ import annotations
import re
from typing import Dict, List, Any
import pandas as pd
from .profiler import profile_all

DATE_RE = re.compile(r"^\s*\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\s*$")
CURRENCY_SYMBOLS = {"$":"USD", "€":"EUR", "£":"GBP", "₹":"INR"}

def quality_scan(tables: Dict[str,pd.DataFrame]) -> List[Dict[str,Any]]:
    issues=[]
    profiles=profile_all(tables)
    for name,p in profiles.items():
        if p["duplicate_rows"]:
            issues.append({"severity":"warning","code":"DUPLICATES","message":f"{name} contains {p['duplicate_rows']} duplicate rows.","details":{"table":name,"count":p["duplicate_rows"]}})
        for col,count in p["missing_values"].items():
            issues.append({"severity":"warning","code":"MISSING_VALUES","message":f"{name}.{col} has {count} missing values.","details":{"table":name,"column":col,"count":count}})
        for col in p["date_candidates"]:
            s=tables[name][col].dropna().astype(str)
            ambiguous=int(s.str.match(DATE_RE).sum())
            if ambiguous:
                issues.append({"severity":"warning","code":"AMBIGUOUS_DATES","message":f"{name}.{col} may contain ambiguous numeric dates such as DD/MM vs MM/DD.","details":{"table":name,"column":col}})
        for col,currencies in p["currency_candidates"].items():
            if len(currencies)>1:
                issues.append({"severity":"critical","code":"CURRENCY_MISMATCH","message":f"{name}.{col} contains multiple currency markers: {', '.join(currencies)}.","details":{"table":name,"column":col,"currencies":currencies}})
    issues.extend(_detect_key_contradictions(tables))
    return issues

def _detect_key_contradictions(tables):
    issues=[]
    # Detect same *_id key appearing in multiple tables with conflicting shared attributes.
    names=list(tables)
    for i in range(len(names)):
        for j in range(i+1,len(names)):
            a,b=tables[names[i]],tables[names[j]]
            common=set(map(str,a.columns)) & set(map(str,b.columns))
            keys=[c for c in common if c.lower().endswith("_id") or c.lower()=="id"]
            for key in keys:
                shared=[c for c in common if c!=key]
                if not shared: continue
                aa=a[[key]+shared].dropna(subset=[key]).drop_duplicates(key)
                bb=b[[key]+shared].dropna(subset=[key]).drop_duplicates(key)
                m=aa.merge(bb,on=key,suffixes=("_a","_b"))
                for c in shared:
                    if f"{c}_a" in m and f"{c}_b" in m:
                        mask=m[f"{c}_a"].astype(str).str.strip()!=m[f"{c}_b"].astype(str).str.strip()
                        n=int(mask.sum())
                        if n:
                            issues.append({"severity":"critical","code":"CONTRADICTION","message":f"Conflicting values for {key} → {c} between {names[i]} and {names[j]} ({n} keys).","details":{"tables":[names[i],names[j]],"key":key,"column":c,"count":n}})
    return issues

def critical_issue(issues):
    return next((x for x in issues if x["severity"]=="critical"), None)
