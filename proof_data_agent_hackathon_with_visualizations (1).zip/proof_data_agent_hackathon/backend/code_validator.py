from __future__ import annotations
import ast

FORBIDDEN={"os","sys","subprocess","socket","requests","urllib","pathlib","shutil","pickle","builtins","ctypes","multiprocessing"}
FORBIDDEN_CALLS={"eval","exec","compile","open","input","__import__"}

def validate_code(code: str):
    errors=[]
    try: tree=ast.parse(code)
    except SyntaxError as e: return False,[f"Syntax error: {e}"]
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root=alias.name.split('.')[0]
                if root not in {"pandas","numpy","math","datetime"}: errors.append(f"Import not allowed: {alias.name}")
        elif isinstance(node, ast.ImportFrom):
            root=(node.module or "").split('.')[0]
            if root not in {"pandas","numpy","math","datetime"}: errors.append(f"Import not allowed: {node.module}")
        elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in FORBIDDEN_CALLS:
            errors.append(f"Call not allowed: {node.func.id}")
        elif isinstance(node, ast.Name) and node.id in FORBIDDEN:
            errors.append(f"Identifier not allowed: {node.id}")
        elif isinstance(node, ast.Attribute) and node.attr.startswith("__"):
            errors.append("Dunder attribute access is not allowed")
    return not errors, errors
