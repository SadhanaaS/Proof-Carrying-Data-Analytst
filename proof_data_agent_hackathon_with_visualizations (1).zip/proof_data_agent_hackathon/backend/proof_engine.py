from __future__ import annotations
from typing import Dict,Any

def build_proof(question, plan, verification, issues, profiles, evidence):
    critical=sum(1 for x in issues if x.get("severity")=="critical")
    warning=sum(1 for x in issues if x.get("severity")=="warning")
    confidence="HIGH" if verification.get("verified") and critical==0 else ("MEDIUM" if verification.get("verified") else "LOW")
    return {
        "status":"VERIFIED" if verification.get("verified") and critical==0 else "NOT VERIFIED",
        "confidence":confidence,
        "question":question,
        "tables_used":plan.get("tables_used",[]),
        "quality_summary":{"critical":critical,"warnings":warning},
        "reproducibility":{"run_1":verification.get("first",{}).get("result"),"run_2":verification.get("second",{}).get("result"),"matched":verification.get("verified",False)},
        "evidence":evidence,
    }
