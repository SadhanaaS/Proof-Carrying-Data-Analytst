from __future__ import annotations
import math
from typing import Any, Dict
from .executor import execute

def normalize(v):
    if hasattr(v,"item"):
        try: return v.item()
        except Exception: pass
    if isinstance(v,float): return round(v,10)
    return v

def verify(code, tables, timeout=8):
    first=execute(code,tables,timeout); second=execute(code,tables,timeout)
    if not first.get("ok") or not second.get("ok"):
        return {"verified":False,"first":first,"second":second,"reason":"Execution failed on at least one run."}
    a,b=normalize(first.get("result")),normalize(second.get("result"))
    same=(a==b)
    if isinstance(a,float) and isinstance(b,float): same=math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-9)
    return {"verified":bool(same),"first":first,"second":second,"reason":"Both executions produced the same result." if same else "Repeated executions produced different results."}
