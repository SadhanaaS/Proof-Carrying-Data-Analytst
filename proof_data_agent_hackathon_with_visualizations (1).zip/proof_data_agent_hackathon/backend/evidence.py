from __future__ import annotations
import pandas as pd
from typing import Dict,Any

def build_evidence(tables: Dict[str,pd.DataFrame], plan: Dict[str,Any], result: Any):
    evidence={"tables":[],"result":result}
    for name in plan.get("tables_used",[]):
        df=tables.get(name)
        if df is None: continue
        evidence["tables"].append({"name":name,"rows":len(df),"columns":list(map(str,df.columns)),"sample_rows":df.head(5).where(pd.notna(df.head(5)),None).to_dict(orient="records")})
    return evidence
