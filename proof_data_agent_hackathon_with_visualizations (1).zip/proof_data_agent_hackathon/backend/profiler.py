from __future__ import annotations
import re
import pandas as pd
from typing import Dict, Any

CURRENCY_RE = re.compile(r"(?:\$|€|£|₹|USD|EUR|GBP|INR)", re.I)

def profile_dataframe(name: str, df: pd.DataFrame) -> Dict[str, Any]:
    date_candidates=[]; numeric=[]; categorical=[]; cols=[]
    missing = {str(c): int(df[c].isna().sum()) for c in df.columns if int(df[c].isna().sum()) > 0}
    dupes = int(df.duplicated().sum())
    currency_candidates={}
    for c in df.columns:
        s=df[c]
        kind="numeric" if pd.api.types.is_numeric_dtype(s) else "categorical"
        if kind=="numeric": numeric.append(str(c))
        else: categorical.append(str(c))
        if pd.api.types.is_datetime64_any_dtype(s): date_candidates.append(str(c))
        elif s.dtype == object:
            sample=s.dropna().astype(str).head(100)
            if len(sample) and sample.str.match(r"^\s*\d{1,4}[-/]\d{1,2}[-/]\d{1,4}\s*$").mean() > 0.6:
                date_candidates.append(str(c))
            currencies=set()
            for val in sample:
                m=CURRENCY_RE.search(val)
                if m: currencies.add(m.group(0).upper())
            if currencies: currency_candidates[str(c)] = sorted(currencies)
        cols.append({"name":str(c),"dtype":str(s.dtype),"non_null":int(s.notna().sum()),"unique":int(s.nunique(dropna=True))})
    return {"name":name,"rows":len(df),"columns":len(df.columns),"columns_info":cols,"missing_values":missing,"duplicate_rows":dupes,"date_candidates":date_candidates,"numeric_columns":numeric,"categorical_columns":categorical,"currency_candidates":currency_candidates}

def profile_all(tables: Dict[str,pd.DataFrame]):
    return {name: profile_dataframe(name,df) for name,df in tables.items()}
