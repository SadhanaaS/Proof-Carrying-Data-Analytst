from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

APP_NAME = "Proof-Carrying Data Analyst"
DEMO_MODE = os.getenv("DEMO_MODE", "true").lower() == "true"
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6-mini")
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "25"))
MAX_EXEC_SECONDS = int(os.getenv("MAX_EXEC_SECONDS", "8"))
MAX_ROWS_FOR_LLM_SAMPLE = int(os.getenv("MAX_ROWS_FOR_LLM_SAMPLE", "20"))
