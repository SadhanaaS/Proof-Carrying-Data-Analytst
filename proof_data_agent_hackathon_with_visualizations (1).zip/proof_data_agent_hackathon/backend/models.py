from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

class QuestionRequest(BaseModel):
    question: str = Field(min_length=3, max_length=2000)
    session_id: Optional[str] = None

class DatasetIssue(BaseModel):
    severity: str
    code: str
    message: str
    details: Dict[str, Any] = {}

class TableProfile(BaseModel):
    name: str
    rows: int
    columns: int
    columns_info: List[Dict[str, Any]]
    missing_values: Dict[str, int]
    duplicate_rows: int
    date_candidates: List[str]
    numeric_columns: List[str]
    categorical_columns: List[str]
    currency_candidates: Dict[str, List[str]] = {}

class AnswerResponse(BaseModel):
    status: str
    answer: Any = None
    display_answer: str = ""
    explanation: str = ""
    confidence: str = ""
    issues: List[Dict[str, Any]] = []
    tables_used: List[str] = []
    proof: Dict[str, Any] = {}
    code: str = ""
    execution: Dict[str, Any] = {}
    evidence: Dict[str, Any] = {}
    clarification: Optional[str] = None
